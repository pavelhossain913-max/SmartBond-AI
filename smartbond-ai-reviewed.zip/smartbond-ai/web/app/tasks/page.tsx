"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
export default function Tasks(){
  const [tok,setTok]=useState("");const [tasks,setTasks]=useState<any[]>([]);const [rem,setRem]=useState<any[]>([]);
  const [title,setTitle]=useState("");const [at,setAt]=useState("");
  const H=(t=tok)=>({"content-type":"application/json",authorization:`Bearer ${t}`});
  async function load(t=tok){const r=await fetch("/api/tasks",{headers:H(t)});const d=await r.json();setTasks(d.tasks||[]);setRem(d.reminders||[]);}
  useEffect(()=>{supabase.auth.getSession().then(r=>{const t=r.data.session?.access_token||"";setTok(t);if(t)load(t);});},[]);
  const patch=async(b:any)=>{await fetch("/api/tasks",{method:"PATCH",headers:H(),body:JSON.stringify(b)});load();};
  return <main style={{maxWidth:720,margin:"0 auto",padding:16}}>
    <a href="/">← Chat</a><h1>Tasks</h1>
    <input placeholder="New task" value={title} onChange={e=>setTitle(e.target.value)}/>
    <input type="datetime-local" value={at} onChange={e=>setAt(e.target.value)}/>
    <button onClick={async()=>{await fetch("/api/tasks",{method:"POST",headers:H(),body:JSON.stringify({title,remindAt:at?new Date(at).toISOString():undefined})});setTitle("");setAt("");load();}}>Add</button>
    {tasks.map(t=>{const r=rem.find(x=>x.task_id===t.id);return <p key={t.id}>
      <input type="checkbox" checked={t.done} onChange={e=>patch({id:t.id,done:e.target.checked})}/> {t.title}
      {r&&!r.confirmed&&<button onClick={()=>patch({id:t.id,confirmReminder:r.id})}>Confirm reminder {new Date(r.remind_at).toLocaleString()}</button>}
      {r?.confirmed&&<small> ⏰ {new Date(r.remind_at).toLocaleString()}</small>}
      <button onClick={async()=>{await fetch(`/api/tasks?id=${t.id}`,{method:"DELETE",headers:H()});load();}}>Delete</button></p>;})}
  </main>;
}
