import "./globals.css";
export default function L({children}:{children:React.ReactNode}){return <html lang="en"><body style={{fontFamily:"system-ui",margin:0}}>{children}</body></html>}
