import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { MODES, SAFETY } from "@/lib/modes";

const Body = z.object({
  conversationId: z.string().uuid().optional(),
  mode: z.string().default("chat"),
  message: z.string().min(1).max(8000),
  untrusted: z.string().max(60000).optional(),
  language: z.enum(["en","bn"]).default("en"),
  source: z.enum(["web","extension"]).default("web"),
});
const hits = new Map<string,number[]>(); // in-memory; use Redis/Upstash in production
function limited(uid:string){const n=Date.now(),a=(hits.get(uid)||[]).filter(t=>n-t<60000);a.push(n);hits.set(uid,a);return a.length>20;}
function cors(req:NextRequest){const o=req.headers.get("origin")||"";const ok=!!o&&o===process.env.EXTENSION_ORIGIN;
 return {
  "Access-Control-Allow-Origin": ok ? o : "null",
  "Access-Control-Allow-Headers": "authorization,content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Max-Age": "600",
  "Vary": "Origin"
};}
export async function OPTIONS(req:NextRequest){return new NextResponse(null,{status:204,headers:cors(req)});}

export async function POST(req:NextRequest){
  const h=cors(req);
  const token=(req.headers.get("authorization")||"").replace("Bearer ","");
  if(!token) return NextResponse.json({error:"Unauthorized"},{status:401,headers:h});
  const sb=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{global:{headers:{Authorization:`Bearer ${token}`}}});
  const {data:{user}}=await sb.auth.getUser(token);
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401,headers:h});
  if(limited(user.id)) return NextResponse.json({error:"Rate limit"},{status:429,headers:h});
  const p=Body.safeParse(await req.json().catch(()=>null));
  if(!p.success) return NextResponse.json({error:"Invalid input"},{status:400,headers:h});
  const b=p.data;
  try{
    let cid=b.conversationId;
    if (!cid) {
      const { data, error } = await sb.from("conversations")
        .insert({ user_id: user.id, title: b.message.slice(0, 60), source: b.source })
        .select("id").single();
      if (error) throw error;
      cid = data.id;
    } else {
      // Never accept a conversation ID solely because it is a valid UUID.
      // Verify ownership before reading history or attaching new messages.
      const { data: owned, error } = await sb.from("conversations")
        .select("id").eq("id", cid).eq("user_id", user.id).maybeSingle();
      if (error || !owned) {
        return NextResponse.json({ error: "Conversation not found" }, { status: 404, headers: h });
      }
    }
    const {data:hist,error:historyError}=await sb.from("messages").select("role,content").eq("conversation_id",cid).order("created_at").limit(30);
    if (historyError) throw historyError;
    const content=b.untrusted?`${b.message}\n\n<untrusted_content>\n${b.untrusted}\n</untrusted_content>`:b.message;
    const model = process.env.ANTHROPIC_MODEL;
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!model || !apiKey) throw new Error("AI provider is not configured");
    const ai = new Anthropic({ apiKey });
    const r=await ai.messages.create({model,max_tokens:1500,
      system:`${MODES[b.mode]||MODES.chat}\nRespond in ${b.language==="bn"?"Bengali":"English"}.\n${SAFETY}`,
      messages:[...(hist||[]).map(m=>({role:m.role as "user"|"assistant",content:m.content})),{role:"user",content}]});
    const text=r.content.map(c=>c.type==="text"?c.text:"").join("");
    const { error: saveError } = await sb.from("messages").insert([
      { conversation_id: cid, user_id: user.id, role: "user", content: b.message },
      { conversation_id: cid, user_id: user.id, role: "assistant", content: text }
    ]);
    if (saveError) throw saveError;
    return NextResponse.json({ conversationId: cid, text }, { headers: h });
  }catch(e){console.error(e);return NextResponse.json({error:"Server error"},{status:500,headers:h});}
}
