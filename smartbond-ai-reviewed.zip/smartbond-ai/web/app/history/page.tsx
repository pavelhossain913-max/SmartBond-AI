"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
export default function History(){
  const [cs,setCs]=useState<any[]>([]);const [open,setOpen]=useState<string>();const [ms,setMs]=useState<any[]>([]);
  const load=()=>supabase.from("conversations").select("id,title,source,created_at").order("created_at",{ascending:false}).then(r=>setCs(r.data||[]));
  useEffect(()=>{load();},[]);
  async function view(id:string){setOpen(id);const r=await supabase.from("messages").select("role,content").eq("conversation_id",id).order("created_at");setMs(r.data||[]);}
  return <main style={{maxWidth:720,margin:"0 auto",padding:16}}><a href="/">← Chat</a><h1>History</h1>
    {cs.map(c=><div key={c.id}><a href="#" onClick={e=>{e.preventDefault();view(c.id);}}>{c.title||"Untitled"}</a> <small>({c.source})</small>
      <button onClick={async()=>{await supabase.from("conversations").delete().eq("id",c.id);load();}}>Delete</button>
      {open===c.id&&ms.map((m,i)=><p key={i}><b>{m.role}:</b> {m.content}</p>)}</div>)}</main>;
}
