"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
const MODES=["chat","writing","english","translate","study","business","marketing","content"];
export default function Home(){
  const [session,setSession]=useState<any>(null);const [email,setEmail]=useState("");const [pw,setPw]=useState("");
  const [mode,setMode]=useState("chat");const [lang,setLang]=useState<"en"|"bn">("en");
  const [msgs,setMsgs]=useState<{role:string;text:string}[]>([]);const [input,setInput]=useState("");const [cid,setCid]=useState<string>();
  useEffect(()=>{supabase.auth.getSession().then(r=>setSession(r.data.session));supabase.auth.onAuthStateChange((_e,s)=>setSession(s));},[]);
  async function send(){
    const m=input;setInput("");setMsgs(x=>[...x,{role:"user",text:m}]);
    const r=await fetch("/api/chat",{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${session.access_token}`},body:JSON.stringify({message:m,mode,language:lang,conversationId:cid})});
    const d=await r.json();if(d.conversationId)setCid(d.conversationId);setMsgs(x=>[...x,{role:"assistant",text:d.text||d.error}]);
  }
  if(!session)return <div style={{padding:24}}><h1>SmartBond AI</h1>
    <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)}/><input type="password" placeholder="password" value={pw} onChange={e=>setPw(e.target.value)}/>
    <button onClick={()=>supabase.auth.signInWithPassword({email,password:pw})}>Sign in</button>
    <button onClick={()=>supabase.auth.signUp({email,password:pw})}>Sign up</button></div>;
  return <div style={{maxWidth:720,margin:"0 auto",padding:16}}>
    <h1>SmartBond AI</h1>
    <select value={mode} onChange={e=>setMode(e.target.value)}>{MODES.map(m=><option key={m}>{m}</option>)}</select>
    <select value={lang} onChange={e=>setLang(e.target.value as any)}><option value="en">English</option><option value="bn">বাংলা</option></select>
    <button onClick={()=>supabase.auth.signOut()}>Sign out</button> <a href="/tasks">Tasks</a> <a href="/history">History</a>
    <div>{msgs.map((m,i)=><p key={i}><b>{m.role}:</b> {m.text}</p>)}</div>
    <input style={{width:"80%"}} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()}/><button onClick={send}>Send</button></div>;
}
