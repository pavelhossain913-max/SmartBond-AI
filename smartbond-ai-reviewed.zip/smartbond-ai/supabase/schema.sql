create table profiles(id uuid primary key references auth.users on delete cascade, display_name text, created_at timestamptz default now());
create table user_settings(user_id uuid primary key references auth.users on delete cascade, language text default 'en', theme text default 'light', extension_enabled boolean default true);
create table subscription_plans(id text primary key, name text, daily_limit int);
create table conversations(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, title text, source text default 'web', created_at timestamptz default now());
create table messages(id uuid primary key default gen_random_uuid(), conversation_id uuid not null references conversations on delete cascade, user_id uuid not null references auth.users on delete cascade, role text check(role in('user','assistant')), content text not null, created_at timestamptz default now());
create table uploaded_files(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, path text, mime text, size int, created_at timestamptz default now());
create table tasks(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, title text not null, done boolean default false, due timestamptz, created_at timestamptz default now());
create table reminders(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, task_id uuid references tasks on delete cascade, remind_at timestamptz not null, repeat text, confirmed boolean default false);
do $$ declare t text; begin
 foreach t in array array['profiles','user_settings','conversations','messages','uploaded_files','tasks','reminders'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy own_%1$s on %1$I for all using (%2$s = auth.uid()) with check (%2$s = auth.uid())', t, case when t='profiles' then 'id' else 'user_id' end);
 end loop; end $$;
alter table subscription_plans enable row level security;
create policy plans_read on subscription_plans for select using (true);
