import {defineConfig} from "vite";import react from "@vitejs/plugin-react";
export default defineConfig({plugins:[react()],build:{outDir:"dist",rollupOptions:{input:{sidepanel:"src/sidepanel.tsx",background:"src/background.ts"},output:{entryFileNames:"[name].js"}}}});
