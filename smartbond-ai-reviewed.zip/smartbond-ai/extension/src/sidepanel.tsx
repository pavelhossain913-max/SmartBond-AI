import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {createClient} from "@supabase/supabase-js";
declare const chrome:any;
const env=(import.meta as any).env;
const API=env.VITE_API_URL as string;
const sb=createClient(env.VITE_SUPABASE_URL,env.VITE_SUPABASE_ANON_KEY,{auth:{storage:{getItem:async(k:string)=>(await chrome.storage.local.get(k))[k]??null,setItem:(k:string,v:string)=>chrome.storage.local.set({[k]:v}),removeItem:(k:string)=>chrome.storage.local.remove(k)}}});
function App(){
  const [s,setS]=useState<any>(null),[e,setE]=useState(""),[p,setP]=useState(""),[lang,setLang]=useState("en"),[inp,setInp]=useState("");
  const [msgs,setMsgs]=useState<any[]>([]),[cid,setCid]=useState<string>(),[enabled,setEn]=useState(true);
  useEffect(()=>{sb.auth.getSession().then(r=>setS(r.data.session));sb.auth.onAuthStateChange((_x,y)=>setS(y));
    chrome.storage.local.get("enabled").then((r:any)=>setEn(r.enabled!==false));},[]);
  useEffect(()=>{if(!s)return;chrome.storage.session.get("pending").then(async(r:any)=>{if(r.pending){await chrome.storage.session.remove("pending");
    ask(r.pending.mode,"Apply this action to the selected text.",r.pending.text);}});},[s]);
  async function ask(mode:string,message:string,untrusted?:string){
    if(!enabled)return;setMsgs(m=>[...m,{r:"user",t:message}]);
    const res=await fetch(`${API}/api/chat`,{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${s.access_token}`},body:JSON.stringify({mode,message,untrusted,language:lang,conversationId:cid,source:"extension"})});
    const d=await res.json();if(d.conversationId)setCid(d.conversationId);setMsgs(m=>[...m,{r:"assistant",t:d.text||d.error}]);
  }
  async function pageAction(mode:string,label:string){ // runs only on explicit click, active tab only
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>document.body.innerText.slice(0,50000)});
    ask(mode,label,result);
  }
  if(!s)return <div><h3>SmartBond AI</h3><input value={e} onChange={x=>setE(x.target.value)} placeholder="email"/><input type="password" value={p} onChange={x=>setP(x.target.value)}/><button onClick={()=>sb.auth.signInWithPassword({email:e,password:p})}>Sign in</button></div>;
  return <div style={{padding:8,fontFamily:"system-ui"}}>
    <label><input type="checkbox" checked={enabled} onChange={x=>{setEn(x.target.checked);chrome.storage.local.set({enabled:x.target.checked});}}/> Enabled</label>
    <select value={lang} onChange={x=>setLang(x.target.value)}><option value="en">English</option><option value="bn">বাংলা</option></select>
    <button onClick={()=>{setMsgs([]);setCid(undefined);}}>Clear</button>
    <button onClick={()=>sb.auth.signOut()}>Sign out</button>
    <button onClick={()=>chrome.tabs.create({url:API})}>Open web app</button>
    <div><button onClick={()=>pageAction("summarize","Summarize this page")}>Summarize page</button>
    <button onClick={()=>pageAction("explain","Explain this page")}>Explain</button>
    <button onClick={()=>pageAction("summarize","Extract important points")}>Key points</button>
    <button onClick={()=>pageAction("translate","Translate this page text")}>Translate</button></div>
    {msgs.map((m,i)=><p key={i}><b>{m.r}:</b> {m.t} {m.r==="assistant"&&<button onClick={()=>navigator.clipboard.writeText(m.t)}>Copy</button>}</p>)}
    <input value={inp} onChange={x=>setInp(x.target.value)} onKeyDown={x=>{if(x.key==="Enter"){ask("chat",inp);setInp("");}}}/></div>;
}
createRoot(document.getElementById("root")!).render(<App/>);
